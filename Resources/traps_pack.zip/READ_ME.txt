Hi I hope you enjoy using these assets! If you're making 2d games and you like this style I've got a website with thousands more assets like these. here's the address if you'd like to check it out.

https://www.gamedeveloperstudio.com




Many thanks and best wishes

Robert Brooks